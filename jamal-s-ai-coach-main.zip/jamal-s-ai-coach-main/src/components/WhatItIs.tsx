import { Card } from "@/components/ui/card";
import { Brain, BookOpen, MessageSquare, Zap } from "lucide-react";

export const WhatItIs = () => {
  return (
    <section className="py-24 bg-background">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            What Is Coach Jamal?
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            A custom-trained AI assistant built entirely from Jamal Reimer's original content and coaching materials — designed to give you instant, high-trust support
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-16">
          <Card className="p-8 bg-card hover:shadow-lg transition-shadow">
            <Brain className="w-12 h-12 text-secondary mb-4" />
            <h3 className="text-2xl font-bold text-foreground mb-3">Trained on the Best</h3>
            <ul className="space-y-2 text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-secondary mt-1">•</span>
                <span>Mega Deal Secrets (book + masterclass)</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-secondary mt-1">•</span>
                <span>Elite Sellers Playbook (full coaching library)</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-secondary mt-1">•</span>
                <span>The Challenge & Pipeline Flywheel programs</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-secondary mt-1">•</span>
                <span>Financial Fluency course</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-secondary mt-1">•</span>
                <span>Hundreds of hours of Jamal's coaching transcripts</span>
              </li>
            </ul>
          </Card>

          <Card className="p-8 bg-card hover:shadow-lg transition-shadow">
            <MessageSquare className="w-12 h-12 text-secondary mb-4" />
            <h3 className="text-2xl font-bold text-foreground mb-3">How You Use It</h3>
            <div className="space-y-4 text-muted-foreground">
              <p>Simply ask Coach Jamal your questions, like:</p>
              <div className="bg-muted/50 p-4 rounded-lg space-y-3 italic">
                <p>"How do I write a POV for cold outbound to a CFO?"</p>
                <p>"What's Jamal's take on executive presence in discovery?"</p>
                <p>"How would you run a high-stakes internal deal review?"</p>
              </div>
              <p className="font-medium text-foreground">
                Get direct, structured responses with frameworks, examples, and actionable next steps — just like Jamal would on a call.
              </p>
            </div>
          </Card>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <Card className="p-6 text-center bg-gradient-to-br from-card to-muted/30 hover:shadow-lg transition-shadow">
            <BookOpen className="w-10 h-10 text-secondary mx-auto mb-3" />
            <h4 className="font-bold text-foreground mb-2">Deep Alignment</h4>
            <p className="text-sm text-muted-foreground">
              Perfectly aligned with Jamal's voice, methods, and strategic frameworks
            </p>
          </Card>

          <Card className="p-6 text-center bg-gradient-to-br from-card to-muted/30 hover:shadow-lg transition-shadow">
            <Zap className="w-10 h-10 text-secondary mx-auto mb-3" />
            <h4 className="font-bold text-foreground mb-2">Instant Access</h4>
            <p className="text-sm text-muted-foreground">
              No scheduling, no waiting — coaching available whenever you need it
            </p>
          </Card>

          <Card className="p-6 text-center bg-gradient-to-br from-card to-muted/30 hover:shadow-lg transition-shadow">
            <Brain className="w-10 h-10 text-secondary mx-auto mb-3" />
            <h4 className="font-bold text-foreground mb-2">Always Learning</h4>
            <p className="text-sm text-muted-foreground">
              Continuously updated with Jamal's latest insights and thinking models
            </p>
          </Card>
        </div>
      </div>
    </section>
  );
};